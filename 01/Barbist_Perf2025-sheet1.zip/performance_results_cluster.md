# Performance Test Results

## System Information

- *Date:* 2025-03-11 18:39:05
- *OS:*Rocky Linux 8.10 (Green Obsidian) on 4.18.0-477.21.1.el8_8.x86_64
- *CPU:*Intel(R) Xeon(R) CPU           X5650  @ 2.67GHz
- *RAM:*62Gi total, 45Gi available
- *Execution Mode:* Cluster (SLURM)

## Notes on Methodology
- Each test performed 4 runs with statistical analysis
- Fast-running programs (<50ms) use high-precision loop timing
- Time measurements in seconds with nanosecond precision where possible
- Standard deviation and variance indicate run-to-run variability
- Memory measurements in kilobytes
- Results available in CSV format at performance_results.csv 
- Cache clearing attempted between test runs for consistent measurements

## delannoy

Delannoy number calculation

### delannoy parameters justification
- Delannoy number calculation
- Selected parameters for this benchmark:
- `5`
- `10`
- `12`
- `13`
- `14`
- `15` timeout 10 minutes


| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `5` | 0.0012932 | 1.000e-10 | 1.000e-10 | 3623 | 1.253e-05 | 0.0012752 | 0.0013031 | 1.000e-10 | High precision mode (1000 iterations per measurement), Cluster execution, Cache cleared, Cache cleared |
| `10` | 0.0273058 | 0.0200000 | 1.000e-10 | 3685 | 6.914e-05 | 0.0272212 | 0.0273712 | 5.000e-09 | High precision mode (100 iterations per measurement), Cluster execution, Cache cleared, Cache cleared |
| `12` | 0.630000 | 0.622500 | 1.000e-10 | 1396 | 1.000e-10 | 0.630000 | 0.630000 | 1.000e-10 | Standard measurement, Cluster execution, Cache cleared, Cache cleared |
| `13` | 3.357500 | 3.350000 | 1.000e-10 | 1407 | 0.0050000 | 3.350000 | 3.360000 | 2.500e-05 | Standard measurement, Cluster execution, Cache cleared, Cache cleared |
| `14` | 12.265000 | 12.237500 | 1.000e-10 | 1382 | 0.0173205 | 12.250000 | 12.290000 | 3.000e-04 | Standard measurement, Cluster execution, Cache cleared, Cache cleared |
## filegen

Small file benchmark

### filegen parameters justification
- Small file benchmark
- Selected parameters for this benchmark:
- `5 10 1024 4096`


| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `5 10 1024 4096` | 0.0104578 | 1.000e-10 | 1.000e-10 | 3599 | 4.471e-04 | 0.0098270 | 0.0108804 | 2.000e-07 | High precision mode (100 iterations per measurement), Cluster execution, Cache cleared, Cache cleared |
## filegen

Medium file benchmark

### filegen parameters justification
- Medium file benchmark
- Selected parameters for this benchmark:
- `10 30 4096 16384`


| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `10 30 4096 16384` | 0.722500 | 0.0600000 | 0.0275000 | 1503 | 0.0298608 | 0.690000 | 0.760000 | 8.917e-04 | Standard measurement, Cluster execution, Cache cleared, Cache cleared |
## filegen

Large file benchmark

### filegen parameters justification
- Large file benchmark
- Selected parameters for this benchmark:
- `20 50 16384 65536`


| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `20 50 16384 65536` | 3.167500 | 0.620000 | 0.135000 | 1666 | 0.0634429 | 3.080000 | 3.230000 | 0.0040250 | Standard measurement, Cluster execution, Cache cleared, Cache cleared |
## filegen

Mixed size benchmark

### filegen parameters justification
- Mixed size benchmark
- Selected parameters for this benchmark:
- `15 40 512 1048576`


| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `15 40 512 1048576` | 6.025000 | 4.282500 | 0.137500 | 3135 | 0.0264575 | 5.990000 | 6.050000 | 7.000e-04 | Standard measurement, Cluster execution, Cache cleared, Cache cleared |
## filesearch

Simple search test

### filesearch parameters justification
- Simple search test
- Selected parameters for this benchmark:



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `` | 0.0033379 | 1.000e-10 | 1.000e-10 | 3609 | 2.411e-05 | 0.0033142 | 0.0033698 | 1.000e-09 | High precision mode (1000 iterations per measurement), Cluster execution, Cache cleared, Cache cleared, Depends on: filegen 5 10 1024 4096 |
## filesearch

Medium complexity search

### filesearch parameters justification
- Medium complexity search
- Selected parameters for this benchmark:



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `` | 0.0044404 | 1.000e-10 | 1.000e-10 | 3574 | 4.030e-05 | 0.0044001 | 0.0044769 | 2.000e-09 | High precision mode (1000 iterations per measurement), Cluster execution, Cache cleared, Cache cleared, Depends on: filegen 15 25 4096 32768 |
## filesearch

Deep directory search

### filesearch parameters justification
- Deep directory search
- Selected parameters for this benchmark:



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `` | 0.0046840 | 1.000e-10 | 1.000e-10 | 3710 | 5.010e-05 | 0.0046440 | 0.0047572 | 3.000e-09 | High precision mode (1000 iterations per measurement), Cluster execution, Cache cleared, Cache cleared, Depends on: filegen 25 15 8192 16384 |
## filesearch

Large file search

### filesearch parameters justification
- Large file search
- Selected parameters for this benchmark:



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `` | 0.0034595 | 1.000e-10 | 1.000e-10 | 3675 | 2.455e-05 | 0.0034372 | 0.0034938 | 1.000e-09 | High precision mode (1000 iterations per measurement), Cluster execution, Cache cleared, Cache cleared, Depends on: filegen 8 10 262144 1048576 |
## filesearch

Many small files search

### filesearch parameters justification
- Many small files search
- Selected parameters for this benchmark:



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `` | 0.0090125 | 1.000e-10 | 1.000e-10 | 3706 | 8.564e-05 | 0.0089223 | 0.0090879 | 7.000e-09 | High precision mode (100 iterations per measurement), Cluster execution, Cache cleared, Cache cleared, Depends on: filegen 20 100 512 4096 |
## mmul200

Matrix multiplication tiny

### mmul200 parameters justification
- Matrix multiplication tiny
- Selected parameters for this benchmark:



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `` | 0.0111389 | 0.0025000 | 1.000e-10 | 3570 | 7.382e-05 | 0.0110396 | 0.0112171 | 5.000e-09 | High precision mode (100 iterations per measurement), Cluster execution, Cache cleared, Cache cleared |
## mmul500

Matrix multiplication small

### mmul500 parameters justification
- Matrix multiplication small
- Selected parameters for this benchmark:



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `` | 0.277604 | 0.270000 | 1.000e-10 | 3631 | 3.494e-04 | 0.277294 | 0.278092 | 1.220e-07 | High precision mode (50 iterations per measurement), Cluster execution, Cache cleared, Cache cleared |
## mmul1000

Matrix multiplication medium

### mmul1000 parameters justification
- Matrix multiplication medium
- Selected parameters for this benchmark:



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `` | 2.040000 | 2.030000 | 1.000e-10 | 24595 | 0.0692820 | 1.980000 | 2.140000 | 0.0048000 | Standard measurement, Cluster execution, Cache cleared, Cache cleared |
## mmul1500

Matrix multiplication large

### mmul1500 parameters justification
- Matrix multiplication large
- Selected parameters for this benchmark:



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `` | 9.542500 | 9.500000 | 0.0050000 | 53915 | 0.0573730 | 9.490000 | 9.610000 | 0.0032917 | Standard measurement, Cluster execution, Cache cleared, Cache cleared |
## mmul2000

Matrix multiplication extra large

### mmul2000 parameters justification
- Matrix multiplication extra large
- Selected parameters for this benchmark:



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `` | 26.372500 | 26.257500 | 0.0150000 | 94854 | 0.370259 | 25.930000 | 26.830000 | 0.137092 | Standard measurement, Cluster execution, Cache cleared, Cache cleared |
## nbody500

N-body simulation small

### nbody500 parameters justification
- N-body simulation small
- Selected parameters for this benchmark:



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `` | 0.320969 | 0.310000 | 1.000e-10 | 3582 | 4.103e-04 | 0.320696 | 0.321572 | 1.680e-07 | High precision mode (50 iterations per measurement), Cluster execution, Cache cleared, Cache cleared |
## nbody1000

N-body simulation medium

### nbody1000 parameters justification
- N-body simulation medium
- Selected parameters for this benchmark:



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `` | 2.552500 | 2.545000 | 1.000e-10 | 1923 | 0.0050000 | 2.550000 | 2.560000 | 2.500e-05 | Standard measurement, Cluster execution, Cache cleared, Cache cleared |
## nbody2000

N-body simulation large

### nbody2000 parameters justification
- N-body simulation large
- Selected parameters for this benchmark:



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `` | 15.330000 | 15.305000 | 1.000e-10 | 1993 | 1.000e-10 | 15.330000 | 15.330000 | 1.000e-10 | Standard measurement, Cluster execution, Cache cleared, Cache cleared |
## nbody1000_200

N-body long simulation

### nbody1000_200 parameters justification
- N-body long simulation
- Selected parameters for this benchmark:



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `` | 5.105000 | 5.100000 | 1.000e-10 | 1876 | 0.0100000 | 5.100000 | 5.120000 | 1.000e-04 | Standard measurement, Cluster execution, Cache cleared, Cache cleared |
## nbody3000

N-body dense simulation

### nbody3000 parameters justification
- N-body dense simulation
- Selected parameters for this benchmark:



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `` | 17.317500 | 17.287500 | 1.000e-10 | 2020 | 0.0287228 | 17.300000 | 17.360000 | 8.250e-04 | Standard measurement, Cluster execution, Cache cleared, Cache cleared |
## qap

QAP small problems

### qap parameters justification
- QAP small problems
- Selected parameters for this benchmark:
- `qap/problems/chr10a.dat`
- `qap/problems/chr12a.dat`
- `qap/problems/chr15a.dat`


| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `qap/problems/chr10a.dat` | 0.0040111 | 1.000e-10 | 1.000e-10 | 3526 | 1.428e-05 | 0.0039990 | 0.0040311 | 1.000e-10 | High precision mode (1000 iterations per measurement), Cluster execution, Cache cleared, Cache cleared |
| `qap/problems/chr12a.dat` | 0.0399429 | 0.0300000 | 1.000e-10 | 3528 | 1.906e-05 | 0.0399177 | 0.0399589 | 1.000e-10 | High precision mode (100 iterations per measurement), Cluster execution, Cache cleared, Cache cleared |
| `qap/problems/chr15a.dat` | 3.480000 | 3.477500 | 1.000e-10 | 1491 | 1.000e-10 | 3.480000 | 3.480000 | 1.000e-10 | Standard measurement, Cluster execution, Cache cleared, Cache cleared |
## qap

QAP medium problems

### qap parameters justification
- QAP medium problems
- Selected parameters for this benchmark:
- `qap/problems/chr18a.dat` timeout 10 minutes
- `qap/problems/chr18b.dat` timeout 10 minutes


| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
