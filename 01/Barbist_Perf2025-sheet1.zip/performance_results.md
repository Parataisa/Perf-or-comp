# Performance Test Results

## System Information

- *Date:* 2025-03-11 18:37:14
- *OS:*Ubuntu 24.04.2 LTS on 5.15.167.4-microsoft-standard-WSL2
- *CPU:*AMD Ryzen 9 3900X 12-Core Processor @4,10GHz
- *RAM:*15Gi total, 14Gi available
- *Execution Mode:* Local

## Notes on Methodology
- Each test performed 4 runs with statistical analysis
- Fast-running programs (<50ms) use high-precision loop timing
- Time measurements in seconds with nanosecond precision where possible
- Standard deviation and variance indicate run-to-run variability
- Memory measurements in kilobytes
- Results available in CSV format at performance_results.csv 
- Cache clearing attempted between test runs for consistent measurements

## delannoy

Delannoy number calculation

### delannoy parameters justification
- Delannoy number calculation
- Selected parameters for this benchmark:
- `5`
- `10`
- `12`
- `13`
- `14`
- `15`



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `5` | 7.544e-04 | 3.250e-05 | 1.900e-04 | 1513 | 1.750e-05 | 7.313e-04 | 7.692e-04 | 1.000e-10 | High precision mode (1000 iterations per measurement), Cache cleared |
| `10` | 0.0108140 | 0.0059000 | 4.000e-04 | 1515 | 1.947e-04 | 0.0106092 | 0.0110115 | 3.800e-08 | High precision mode (100 iterations per measurement), Cache cleared |
| `12` | 0.125162 | 0.119500 | 5.000e-04 | 1485 | 6.334e-04 | 0.124465 | 0.125999 | 4.010e-07 | High precision mode (50 iterations per measurement), Cache cleared |
| `13` | 0.647500 | 0.642500 | 1.000e-10 | 1496 | 0.0309570 | 0.620000 | 0.690000 | 9.583e-04 | Cache cleared |
| `14` | 3.882500 | 3.880000 | 1.000e-10 | 1500 | 0.0359398 | 3.830000 | 3.910000 | 0.0012917 | Cache cleared |
| `15` | 53.555000 | 53.550000 | 1.000e-10 | 1518 | 0.196723 | 53.390000 | 53.840000 | 0.0387000 | Cache cleared |
## filegen

Small file benchmark

### filegen parameters justification
- Small file benchmark
- Selected parameters for this benchmark:
- `5 10 1024 4096`


| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `5 10 1024 4096` | 0.0046829 | 5.900e-04 | 8.400e-04 | 1658 | 4.696e-05 | 0.0046183 | 0.0047187 | 2.000e-09 | High precision mode (1000 iterations per measurement), Cache cleared |
## filegen

Medium file benchmark

### filegen parameters justification
- Medium file benchmark
- Selected parameters for this benchmark:
- `10 30 4096 16384`


| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `10 30 4096 16384` | 0.0628984 | 0.0342000 | 0.0238500 | 1737 | 1.566e-04 | 0.0627238 | 0.0630966 | 2.500e-08 | High precision mode (100 iterations per measurement), Cache cleared |
## filegen

Large file benchmark

### filegen parameters justification
- Large file benchmark
- Selected parameters for this benchmark:
- `20 50 16384 65536`


| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `20 50 16384 65536` | 0.587500 | 0.450000 | 0.127500 | 1868 | 0.0095743 | 0.580000 | 0.600000 | 9.167e-05 | Cache cleared |
## filegen

Mixed size benchmark

### filegen parameters justification
- Mixed size benchmark
- Selected parameters for this benchmark:
- `15 40 512 1048576`


| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `15 40 512 1048576` | 3.992500 | 3.495000 | 0.480000 | 3423 | 0.0419325 | 3.950000 | 4.050000 | 0.0017583 | Cache cleared |
## filesearch

Simple search test

### filesearch parameters justification
- Simple search test
- Selected parameters for this benchmark:



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `` | 0.0013306 | 8.750e-05 | 2.050e-04 | 1654 | 2.775e-05 | 0.0012986 | 0.0013649 | 1.000e-09 | High precision mode (1000 iterations per measurement), Cache cleared, Depends on: filegen 5 10 1024 4096 |
## filesearch

Medium complexity search

### filesearch parameters justification
- Medium complexity search
- Selected parameters for this benchmark:



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `` | 0.0018341 | 8.750e-05 | 2.950e-04 | 1667 | 3.456e-05 | 0.0017962 | 0.0018655 | 1.000e-09 | High precision mode (1000 iterations per measurement), Cache cleared, Depends on: filegen 15 25 4096 32768 |
## filesearch

Many directory search

### filesearch parameters justification
- Many directory search
- Selected parameters for this benchmark:



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `` | 0.0039801 | 1.950e-04 | 8.675e-04 | 1646 | 4.668e-05 | 0.0039440 | 0.0040483 | 2.000e-09 | High precision mode (1000 iterations per measurement), Cache cleared, Depends on: filegen 100 15 8192 8192 |
## filesearch

Large file search

### filesearch parameters justification
- Large file search
- Selected parameters for this benchmark:



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `` | 0.0013601 | 4.250e-05 | 2.225e-04 | 1652 | 2.589e-05 | 0.0013397 | 0.0013972 | 1.000e-09 | High precision mode (1000 iterations per measurement), Cache cleared, Depends on: filegen 8 10 1048576 1048576 |
## filesearch

Many small files search

### filesearch parameters justification
- Many small files search
- Selected parameters for this benchmark:



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `` | 0.0042185 | 2.225e-04 | 9.575e-04 | 1674 | 2.490e-05 | 0.0041946 | 0.0042496 | 1.000e-09 | High precision mode (1000 iterations per measurement), Cache cleared, Depends on: filegen 20 100 512 512 |
## mmul200

Matrix multiplication tiny

### mmul200 parameters justification
- Matrix multiplication tiny
- Selected parameters for this benchmark:



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `` | 0.0066437 | 0.0021950 | 3.700e-04 | 2148 | 3.224e-05 | 0.0066151 | 0.0066743 | 1.000e-09 | High precision mode (1000 iterations per measurement), Cache cleared |
## mmul500

Matrix multiplication small

### mmul500 parameters justification
- Matrix multiplication small
- Selected parameters for this benchmark:



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `` | 0.0959177 | 0.0880500 | 0.0032250 | 7000 | 4.693e-04 | 0.0956660 | 0.0966214 | 2.200e-07 | High precision mode (100 iterations per measurement), Cache cleared |
## mmul1000

Matrix multiplication medium

### mmul1000 parameters justification
- Matrix multiplication medium
- Selected parameters for this benchmark:



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `` | 0.792500 | 0.777500 | 0.0025000 | 24645 | 0.0377492 | 0.750000 | 0.840000 | 0.0014250 | Cache cleared |
## mmul1500

Matrix multiplication large

### mmul1500 parameters justification
- Matrix multiplication large
- Selected parameters for this benchmark:



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `` | 4.690000 | 4.657500 | 0.0150000 | 53760 | 0.169902 | 4.450000 | 4.840000 | 0.0288667 | Cache cleared |
## mmul2000

Matrix multiplication extra large

### mmul2000 parameters justification
- Matrix multiplication extra large
- Selected parameters for this benchmark:



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `` | 13.647500 | 13.610000 | 0.0200000 | 94881 | 0.473313 | 13.070000 | 14.210000 | 0.224025 | Cache cleared |
## nbody500

N-body simulation small

### nbody500 parameters justification
- N-body simulation small
- Selected parameters for this benchmark:



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `` | 0.0646765 | 0.0594000 | 7.000e-04 | 1658 | 3.730e-04 | 0.0643302 | 0.0650440 | 1.390e-07 | High precision mode (100 iterations per measurement), Cache cleared |
## nbody1000

N-body simulation medium

### nbody1000 parameters justification
- N-body simulation medium
- Selected parameters for this benchmark:



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `` | 0.502500 | 0.497500 | 1.000e-10 | 1654 | 0.0050000 | 0.500000 | 0.510000 | 2.500e-05 | Cache cleared |
## nbody2000

N-body simulation large

### nbody2000 parameters justification
- N-body simulation large
- Selected parameters for this benchmark:



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `` | 3.025000 | 3.017500 | 1.000e-10 | 1751 | 0.0173205 | 3.000000 | 3.040000 | 3.000e-04 | Cache cleared |
## nbody1000_200

N-body long simulation

### nbody1000_200 parameters justification
- N-body long simulation
- Selected parameters for this benchmark:



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `` | 1.007500 | 1.000000 | 1.000e-10 | 1643 | 0.0095743 | 1.000000 | 1.020000 | 9.167e-05 | Cache cleared |
## nbody3000

N-body dense simulation

### nbody3000 parameters justification
- N-body dense simulation
- Selected parameters for this benchmark:



| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `` | 3.425000 | 3.422500 | 1.000e-10 | 1796 | 0.0300000 | 3.390000 | 3.450000 | 9.000e-04 | Cache cleared |
## qap

QAP small problems

### qap parameters justification
- QAP small problems
- Selected parameters for this benchmark:
- `qap/problems/chr10a.dat`
- `qap/problems/chr12a.dat`
- `qap/problems/chr15a.dat`


| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `qap/problems/chr10a.dat` | 0.0021435 | 1.925e-04 | 2.050e-04 | 1709 | 2.405e-05 | 0.0021288 | 0.0021793 | 1.000e-09 | High precision mode (1000 iterations per measurement), Cache cleared |
| `qap/problems/chr12a.dat` | 0.0188733 | 0.0136500 | 5.250e-04 | 1716 | 2.186e-04 | 0.0186793 | 0.0191788 | 4.800e-08 | High precision mode (100 iterations per measurement), Cache cleared |
| `qap/problems/chr15a.dat` | 1.735000 | 1.730000 | 1.000e-10 | 1680 | 0.0057735 | 1.730000 | 1.740000 | 3.333e-05 | Cache cleared |
## qap

QAP medium problems

### qap parameters justification
- QAP medium problems
- Selected parameters for this benchmark:
- `qap/problems/chr18a.dat`
- `qap/problems/chr18b.dat` cancelled 15 minutes


| Parameters | Avg Time (s) | User CPU (s) | System CPU (s) | Memory (KB) | Std Dev (s) | Min Time (s) | Max Time (s) | Variance (s²) | Notes |
|------------|--------------|--------------|----------------|-------------|-------------|-------------|-------------|--------------|-------|
| `qap/problems/chr18a.dat` | 89.855000 | 89.850000 | 1.000e-10 | 1738 | 0.833167 | 88.740000 | 90.670000 | 0.694167 | Cache cleared |
