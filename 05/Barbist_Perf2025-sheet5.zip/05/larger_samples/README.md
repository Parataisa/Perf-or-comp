This folder contains some slightly larger C benchmark codes.

Basic build instructions (from each individual benchmark directory):

```bash
mkdir build
cd build
cmake .. -G Ninja -DCMAKE_BUILD_TYPE=Release
ninja
```
